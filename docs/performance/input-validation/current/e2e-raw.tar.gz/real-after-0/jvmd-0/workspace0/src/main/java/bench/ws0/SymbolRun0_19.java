package bench.ws0;
public class SymbolRun0_19 {
int use(){return SymbolRun0_0.twice(19);}
}
