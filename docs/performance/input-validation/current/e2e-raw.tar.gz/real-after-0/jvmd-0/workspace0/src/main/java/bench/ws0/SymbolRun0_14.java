package bench.ws0;
public class SymbolRun0_14 {
int use(){return SymbolRun0_0.twice(14);}
}
