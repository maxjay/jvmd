package bench.ws1;
public class SymbolRun1_0 {
public static int twice(int value){return value*2;}
}
