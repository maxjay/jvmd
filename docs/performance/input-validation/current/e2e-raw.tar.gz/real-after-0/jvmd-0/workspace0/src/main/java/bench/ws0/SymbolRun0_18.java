package bench.ws0;
public class SymbolRun0_18 {
int use(){return SymbolRun0_0.twice(18);}
}
