package bench.ws1;
public class SymbolRun1_1 {
int use(){int local=1;return SymbolRun1_0.twice(local);}
Object binary(com.fasterxml.jackson.databind.ObjectMapper dependency){return dependency.getFactory();}
}
