package bench.ws1;
public class SymbolRun1_14 {
int use(){return SymbolRun1_0.twice(14);}
}
