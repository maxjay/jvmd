public class Pressure {
 static class Type0 { public int unique0(){return 0;} }
 int use0(Type0 x){return x.unique0();}
 static class Type1 { public int unique1(){return 1;} }
 int use1(Type1 x){return x.unique1();}
 static class Type2 { public int unique2(){return 2;} }
 int use2(Type2 x){return x.unique2();}
 static class Type3 { public int unique3(){return 3;} }
 int use3(Type3 x){return x.unique3();}
 static class Type4 { public int unique4(){return 4;} }
 int use4(Type4 x){return x.unique4();}
 static class Type5 { public int unique5(){return 5;} }
 int use5(Type5 x){return x.unique5();}
 static class Type6 { public int unique6(){return 6;} }
 int use6(Type6 x){return x.unique6();}
 static class Type7 { public int unique7(){return 7;} }
 int use7(Type7 x){return x.unique7();}
 static class Type8 { public int unique8(){return 8;} }
 int use8(Type8 x){return x.unique8();}
 static class Type9 { public int unique9(){return 9;} }
 int use9(Type9 x){return x.unique9();}
 static class Type10 { public int unique10(){return 10;} }
 int use10(Type10 x){return x.unique10();}
 static class Type11 { public int unique11(){return 11;} }
 int use11(Type11 x){return x.unique11();}
 static class Type12 { public int unique12(){return 12;} }
 int use12(Type12 x){return x.unique12();}
 static class Type13 { public int unique13(){return 13;} }
 int use13(Type13 x){return x.unique13();}
 static class Type14 { public int unique14(){return 14;} }
 int use14(Type14 x){return x.unique14();}
 static class Type15 { public int unique15(){return 15;} }
 int use15(Type15 x){return x.unique15();}
 static class Type16 { public int unique16(){return 16;} }
 int use16(Type16 x){return x.unique16();}
 static class Type17 { public int unique17(){return 17;} }
 int use17(Type17 x){return x.unique17();}
 static class Type18 { public int unique18(){return 18;} }
 int use18(Type18 x){return x.unique18();}
 static class Type19 { public int unique19(){return 19;} }
 int use19(Type19 x){return x.unique19();}
 static class Type20 { public int unique20(){return 20;} }
 int use20(Type20 x){return x.unique20();}
 static class Type21 { public int unique21(){return 21;} }
 int use21(Type21 x){return x.unique21();}
 static class Type22 { public int unique22(){return 22;} }
 int use22(Type22 x){return x.unique22();}
 static class Type23 { public int unique23(){return 23;} }
 int use23(Type23 x){return x.unique23();}
}
