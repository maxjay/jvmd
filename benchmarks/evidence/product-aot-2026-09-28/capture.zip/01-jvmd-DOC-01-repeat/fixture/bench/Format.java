package bench;
public class Format {public int value( ){return 1+2;}}
