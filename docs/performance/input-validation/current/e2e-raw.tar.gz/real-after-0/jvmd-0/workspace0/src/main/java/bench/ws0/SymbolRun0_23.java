package bench.ws0;
public class SymbolRun0_23 {
int use(){return SymbolRun0_0.twice(23);}
}
