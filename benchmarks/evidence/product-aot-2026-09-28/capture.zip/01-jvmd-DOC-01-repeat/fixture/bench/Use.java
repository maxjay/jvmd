package bench;
public class Use {
    public String read(Customer customer) { return customer.name(); }
    public int count(Customer customer) { return customer.number(); }
    public int twice(Customer customer) { return customer.number() + customer.number(); }
    public String join(Customer customer) { return customer.join("a", 2); }
}
