import json,subprocess
from pathlib import Path
root=Path('/workspace/scratch/7164a0d102d4/semantic-recovery')
repo=Path('/workspace/scratch/7164a0d102d4/jvmd-review')
build=json.loads((root/'consolidated-v1/build.json').read_text())
out=root/'warm-trace-dispatch';out.mkdir(exist_ok=True)
source=(repo/'jvmd-core/src/main/java/dev/jvmd/core/Dispatcher.java').read_text()
source=source.replace('long start = System.nanoTime();','long start = System.nanoTime(); var trace = new java.util.LinkedHashMap<String,Long>();')
for needle,label in [('if (envelope == null) throw','handler'),('if(id!=null)response=budgets.enforce(response,method,params);','tree'),('metrics.record(method, sessionId,','budget'),('return id == null && validRequest ? null : response;','metrics')]:
 pos=source.index(needle);source=source[:pos]+f'trace.put("{label}",System.nanoTime()-start); '+source[pos:]
source=source.replace('return id == null && validRequest ? null : response;', 'if(method.equals("symbol.references"))System.err.println("WARM_TRACE "+trace); return id == null && validRequest ? null : response;')
(out/'Dispatcher.java').write_text(source)
(out/'WarmFirstProbe.java').write_text('''import java.nio.file.*; import dev.jvmd.core.Json; public class WarmFirstProbe {public static void main(String[] args)throws Exception {NavigationBenchmark.navigation(Path.of(args[0]),32,"workspace_32",0); System.out.println(Json.MAPPER.writeValueAsString(NavigationBenchmark.samples));}}''')
classes=out/'classes'; classes.mkdir(exist_ok=True)
cmd=[build['java'].replace('/java','/javac'),'-cp',build['classpath'],'-d',str(classes),str(out/'Dispatcher.java'),str(out/'WarmFirstProbe.java')]
subprocess.run(cmd,check=True)
for i in range(3):
 cmd=[build['java'],'-Xms256m','-Xmx1g','-XX:+UseG1GC','--enable-native-access=ALL-UNNAMED',*[f'--add-exports=jdk.compiler/com.sun.tools.javac.{p}=ALL-UNNAMED' for p in ['api','util','code','main','platform']],'-cp',str(classes)+':'+build['classpath'],'WarmFirstProbe',str(out/f'run{i}')]
 with (out/f'run{i}.log').open('w') as log:subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True)
 print(i,flush=True)
