import json,subprocess
from pathlib import Path
root=Path('/workspace/scratch/7164a0d102d4/semantic-recovery')
repo=Path('/workspace/scratch/7164a0d102d4/jvmd-review')
build=json.loads((root/'consolidated-v1/build.json').read_text())
out=root/'warm-trace';out.mkdir(exist_ok=True)
source=(repo/'jvmd-dist/src/main/java/dev/jvmd/dist/Application.java').read_text()
start=source.index('    private Envelope relationships(');end=source.index('    private static <T> List<T> slice',start)
part=source[start:end]
part=part.replace('String ref=Dispatcher.required(params,"ref");','long traceStart=System.nanoTime(); var trace=new java.util.LinkedHashMap<String,Long>(); String ref=Dispatcher.required(params,"ref");',1)
for needle,label in [('var description=describe(session,ref,snapshot);','validation'),('String key=symbol.get("scip").toString();','description'),('var reached=new LinkedHashSet<String>();','index'),('expansion.symbols().forEach','expansion'),('var edgeList=List.copyOf(selected);','edges'),('var nodes=reached.stream()','references')]:
 pos=part.index(needle);part=part[:pos]+f'trace.put("{label}",System.nanoTime()-traceStart); '+part[pos:]
part=part.replace('return new Envelope(tier,"live",more,','System.err.println("WARM_TRACE "+Json.MAPPER.writeValueAsString(trace)); return new Envelope(tier,"live",more,')
(out/'Application.java').write_text(source[:start]+part+source[end:])
(out/'WarmFirstProbe.java').write_text('''import java.nio.file.*; import dev.jvmd.core.Json; public class WarmFirstProbe {public static void main(String[] args)throws Exception {NavigationBenchmark.navigation(Path.of(args[0]),32,"workspace_32",0); System.out.println(Json.MAPPER.writeValueAsString(NavigationBenchmark.samples));}}''')
classes=out/'classes'; classes.mkdir(exist_ok=True)
cmd=[build['java'].replace('/java','/javac'),'-cp',build['classpath'],'-d',str(classes),str(out/'Application.java'),str(out/'WarmFirstProbe.java')]
subprocess.run(cmd,check=True)
for i in range(3):
 cmd=[build['java'],'-Xms256m','-Xmx1g','-XX:+UseG1GC','--enable-native-access=ALL-UNNAMED',*[f'--add-exports=jdk.compiler/com.sun.tools.javac.{p}=ALL-UNNAMED' for p in ['api','util','code','main','platform']],'-cp',str(classes)+':'+build['classpath'],'WarmFirstProbe',str(out/f'run{i}')]
 with (out/f'run{i}.log').open('w') as log:subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True)
 print(i,flush=True)
