package bench.ws0;
public class SymbolRun0_28 {
int use(){return SymbolRun0_0.twice(28);}
}
