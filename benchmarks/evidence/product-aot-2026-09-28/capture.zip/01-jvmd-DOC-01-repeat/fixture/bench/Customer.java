package bench;
/** A customer in the exact benchmark fixture. */
public class Customer {
    public String label = "Ada";
    /** NAME_DOC_V1 */
    public String name() { return label; }
    /** NUMBER_DOC_V1 */
    public int number() { return 7; }
    /** JOIN_DOC_V1 */
    public String join(String left, int right) { return left + right; }
}
