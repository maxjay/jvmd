package bench.ws1;
public class SymbolRun1_30 {
int use(){return SymbolRun1_0.twice(30);}
}
