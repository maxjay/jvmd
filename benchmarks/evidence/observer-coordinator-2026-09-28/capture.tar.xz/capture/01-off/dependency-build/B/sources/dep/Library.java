package dep;
/** LIBRARY_DOC_ATTACHED_V2 */
public class Library {
    /** MEMBER_DOC_ATTACHED_V2 */ public String next() { return "B"; }
}
