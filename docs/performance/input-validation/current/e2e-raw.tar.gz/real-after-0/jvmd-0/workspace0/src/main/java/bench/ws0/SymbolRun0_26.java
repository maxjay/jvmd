package bench.ws0;
public class SymbolRun0_26 {
int use(){return SymbolRun0_0.twice(26);}
}
