package bench;
public class Calls {
    public int a() { return b() + b(); }
    public int b() { return c(); }
    public int c() { return 3; }
    public int d() { return 4; }
}
