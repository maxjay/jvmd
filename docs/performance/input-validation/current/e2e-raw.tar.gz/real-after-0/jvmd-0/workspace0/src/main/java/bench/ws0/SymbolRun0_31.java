package bench.ws0;
public class SymbolRun0_31 {
int use(){return SymbolRun0_0.twice(31);}
}
