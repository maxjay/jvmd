package bench.ws1;
public class SymbolRun1_27 {
int use(){return SymbolRun1_0.twice(27);}
}
