package bench.ws1;
public class SymbolRun1_12 {
int use(){return SymbolRun1_0.twice(12);}
}
