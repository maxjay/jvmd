package bench.ws0;
public class SymbolRun0_15 {
int use(){return SymbolRun0_0.twice(15);}
}
