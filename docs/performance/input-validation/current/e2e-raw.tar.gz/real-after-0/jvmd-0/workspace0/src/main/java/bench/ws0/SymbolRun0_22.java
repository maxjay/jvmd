package bench.ws0;
public class SymbolRun0_22 {
int use(){return SymbolRun0_0.twice(22);}
}
