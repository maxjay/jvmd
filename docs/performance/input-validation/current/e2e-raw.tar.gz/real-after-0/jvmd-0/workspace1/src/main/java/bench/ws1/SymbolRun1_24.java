package bench.ws1;
public class SymbolRun1_24 {
int use(){return SymbolRun1_0.twice(24);}
}
