package bench.ws0;
public class SymbolRun0_0 {
public static int twice(int value){return value*2;}
}
