package bench.ws0;
public class SymbolRun0_24 {
int use(){return SymbolRun0_0.twice(24);}
}
