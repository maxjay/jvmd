package bench.ws1;
public class SymbolRun1_22 {
int use(){return SymbolRun1_0.twice(22);}
}
