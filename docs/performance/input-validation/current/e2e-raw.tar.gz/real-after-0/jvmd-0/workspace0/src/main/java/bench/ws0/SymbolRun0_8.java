package bench.ws0;
public class SymbolRun0_8 {
int use(){return SymbolRun0_0.twice(8);}
}
