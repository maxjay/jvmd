import json,subprocess,statistics,sys
from pathlib import Path
root=Path('/workspace/scratch/7164a0d102d4/semantic-recovery');out=root/sys.argv[1];out.mkdir()
variants=sys.argv[2:];results=[]
for i in range(6):
 for variant in variants[i%len(variants):]+variants[:i%len(variants)]:
  build=json.loads((root/variant/'build.json').read_text());run=out/f'{i}-{variant}';run.mkdir()
  cmd=[build['java'],'-Xms256m','-Xmx1g','-XX:+UseG1GC','--enable-native-access=ALL-UNNAMED',*[f'--add-exports=jdk.compiler/com.sun.tools.javac.{p}=ALL-UNNAMED' for p in ['api','util','code','main','platform']],'-cp',build['classpath']+':'+str(root/'warm-trace/classes'),'WarmFirstProbe',str(run/'workspace')]
  (run/'command.json').write_text(json.dumps(cmd))
  with (run/'run.log').open('w') as log:subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True)
  samples=json.loads((run/'run.log').read_text().splitlines()[-1]);row={'variant':variant,'pair':i,'samples':samples};results.append(row)
  (out/'runs.json').write_text(json.dumps(results,indent=2))
  print(i,variant,round(statistics.median(s['ms'] for s in samples if s['phase']=='warm'),3),flush=True)
for variant in variants:
 for metric in ['ms','allocated_bytes']:
  values=[statistics.median(s[metric] for s in row['samples'] if s['phase']=='warm') for row in results if row['variant']==variant];print(variant,metric,statistics.median(values))
