package bench.ws0;
public class SymbolRun0_25 {
int use(){return SymbolRun0_0.twice(25);}
}
