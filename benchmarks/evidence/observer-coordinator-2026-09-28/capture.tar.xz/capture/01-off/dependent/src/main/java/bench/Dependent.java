package bench; public class Dependent { public String read(dep.Library l) { return l.original(); } }
