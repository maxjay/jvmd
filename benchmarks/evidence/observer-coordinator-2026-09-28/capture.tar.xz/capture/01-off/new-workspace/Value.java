public class Value { public String marker = "disk"; }
