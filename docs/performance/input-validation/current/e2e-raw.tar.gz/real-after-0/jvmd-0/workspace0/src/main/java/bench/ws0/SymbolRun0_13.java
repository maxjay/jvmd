package bench.ws0;
public class SymbolRun0_13 {
int use(){return SymbolRun0_0.twice(13);}
}
