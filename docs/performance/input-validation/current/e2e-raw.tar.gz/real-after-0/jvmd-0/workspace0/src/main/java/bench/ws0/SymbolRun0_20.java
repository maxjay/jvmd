package bench.ws0;
public class SymbolRun0_20 {
int use(){return SymbolRun0_0.twice(20);}
}
