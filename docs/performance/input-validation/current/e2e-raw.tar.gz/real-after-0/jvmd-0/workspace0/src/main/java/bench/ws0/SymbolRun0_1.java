package bench.ws0;
public class SymbolRun0_1 {
int use(){int local=1;return SymbolRun0_0.twice(local);}
Object binary(com.fasterxml.jackson.databind.ObjectMapper dependency){return dependency.getFactory();}
}
