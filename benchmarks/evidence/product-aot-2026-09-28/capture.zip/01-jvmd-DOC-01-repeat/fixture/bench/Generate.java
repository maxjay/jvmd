package bench;
public class Generate {
    private String name;
    private int number;
    private Customer delegate;
}
