package bench.ws1;
public class SymbolRun1_15 {
int use(){return SymbolRun1_0.twice(15);}
}
