package bench;
public class Unrelated {
    public String name() { return "unrelated"; }
    public String label = "unrelated";
    public int number() { return 73; }
}
