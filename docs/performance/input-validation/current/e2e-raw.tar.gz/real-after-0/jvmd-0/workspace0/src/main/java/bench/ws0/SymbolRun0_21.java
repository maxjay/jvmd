package bench.ws0;
public class SymbolRun0_21 {
int use(){return SymbolRun0_0.twice(21);}
}
