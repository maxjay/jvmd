package bench.ws0;
public class SymbolRun0_6 {
int use(){return SymbolRun0_0.twice(6);}
}
