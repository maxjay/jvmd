package bench;
interface Root { int value(); }
class Base implements Root { public int value() { return 1; } }
class Child extends Base { public int value() { return 2; } }
class UnrelatedType { public int value() { return 3; } }
