package bench.ws0;
public class SymbolRun0_2 {
int use(){return SymbolRun0_0.twice(2);}
}
