package bench.ws1;
public class SymbolRun1_7 {
int use(){return SymbolRun1_0.twice(7);}
}
